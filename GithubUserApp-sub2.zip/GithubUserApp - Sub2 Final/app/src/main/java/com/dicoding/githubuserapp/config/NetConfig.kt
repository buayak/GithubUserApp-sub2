package com.dicoding.githubuserapp.config

object NetConfig {
    const val BASE_URL = "https://api.github.com/"
    const val GITHUB_TOKEN = "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"
}